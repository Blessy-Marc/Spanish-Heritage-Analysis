import io
import math
import re
from datetime import datetime

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import sympy as sp

# ------------------------------------------------------------
# Afro-Dominican Population Explorer
# Data transcribed from the user's presentation (1950-2024).
# These are presentation estimates, not verified census counts.
# ------------------------------------------------------------

st.set_page_config(page_title="Afro-Dominican Population Explorer", page_icon="🌺", layout="wide")

YEARS = np.array([1950, 1960, 1970, 1980, 1990, 2000, 2010, 2015, 2020, 2024], dtype=int)
POPULATION = np.array([500000, 700000, 900000, 1200000, 1500000, 1800000, 2300000, 2400000, 2500000, 2600000], dtype=float)
SOURCE_DF = pd.DataFrame({"Year": YEARS, "Estimated population": POPULATION.astype(int)})

CONTEXTS = {
    "Population / biology": {
        "description": "Explore the estimated size of a population over time.",
        "x": "Year", "xunit": "calendar year", "y": "Population", "yunit": "people",
        "suggestion": "polynomial", "visual": "Population / cell colony"
    },
    "Business": {"description": "Model a business measure changing over time.", "x": "Year", "xunit": "year", "y": "Business measure", "yunit": "units", "suggestion": "exponential", "visual": "Business indicator"},
    "Engineering": {"description": "Model a measurable engineering quantity.", "x": "Time", "xunit": "seconds", "y": "Output", "yunit": "units", "suggestion": "polynomial", "visual": "Moving object"},
    "Medical": {"description": "Explore a medical quantity such as concentration over time. This is a classroom illustration, not medical guidance.", "x": "Time", "xunit": "hours", "y": "Concentration", "yunit": "mg/L", "suggestion": "exponential", "visual": "Tank / concentration"},
    "Sports science": {"description": "Model a sports-science measurement over time.", "x": "Time", "xunit": "seconds", "y": "Performance", "yunit": "units", "suggestion": "trigonometric", "visual": "Moving object"},
    "Bioengineering": {"description": "Model a biological or engineered system.", "x": "Time", "xunit": "hours", "y": "System output", "yunit": "units", "suggestion": "logarithmic", "visual": "Population / cell colony"},
    "Economic forecasting": {"description": "Explore an economic indicator over time.", "x": "Year", "xunit": "year", "y": "Economic indicator", "yunit": "index units", "suggestion": "polynomial", "visual": "Business indicator"},
    "Weather": {"description": "Model a weather measurement over time.", "x": "Time", "xunit": "days", "y": "Weather measure", "yunit": "units", "suggestion": "trigonometric", "visual": "Thermometer"},
    "Custom": {"description": "Define your own context and variables.", "x": "Input", "xunit": "units", "y": "Output", "yunit": "units", "suggestion": "polynomial", "visual": "Moving object"},
}

FUNCTIONS = ["Data best-fit polynomial", "Suggested function", "Build with parameters", "Enter my own function"]
MODES = ["Honors Algebra 2", "Precalculus", "Calculus"]

def fmt_num(v):
    if not np.isfinite(v):
        return "undefined"
    return f"{v:,.4g}"

def safe_expression(expr_text, x_symbol):
    """Parse a familiar math expression using a restricted SymPy namespace."""
    allowed = {
        "x": x_symbol, "pi": sp.pi, "E": sp.E,
        "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
        "exp": sp.exp, "log": sp.log, "sqrt": sp.sqrt,
        "abs": sp.Abs
    }
    cleaned = expr_text.replace("^", "**")
    if not re.fullmatch(r"[0-9xX+\-*/().,\sA-Za-z_]*", cleaned):
        raise ValueError("Use numbers, x, parentheses, + - * /, powers, and supported functions.")
    cleaned = re.sub(r"\bX\b", "x", cleaned)
    try:
        expr = sp.sympify(cleaned, locals=allowed, evaluate=True)
    except Exception as exc:
        raise ValueError("I could not read that function. Check parentheses and operators.") from exc
    if expr.free_symbols - {x_symbol}:
        raise ValueError("The function can only contain the variable x.")
    return expr

def numeric_function(expr, x_symbol):
    f = sp.lambdify(x_symbol, expr, modules=["numpy"])
    def evaluate(values):
        arr = np.asarray(values, dtype=float)
        with np.errstate(all="ignore"):
            out = f(arr)
        if np.isscalar(out):
            out = np.full(arr.shape, float(out))
        return np.asarray(out, dtype=float)
    return evaluate

def polyfit_model(df, degree):
    x = df["Year"].to_numpy(dtype=float)
    y = df["Estimated population"].to_numpy(dtype=float)
    base = float(np.mean(x))
    t = x - base
    coeff = np.polyfit(t, y, degree)
    pred = np.polyval(coeff, t)
    residual = y - pred
    ss_res = float(np.sum(residual**2))
    ss_tot = float(np.sum((y - np.mean(y))**2))
    r2 = 1 - ss_res / ss_tot if ss_tot else float("nan")
    mae = float(np.mean(np.abs(residual)))
    return base, coeff, pred, residual, r2, mae

def poly_expr(coeff, base, x):
    t = x - sp.Float(base)
    return sum(sp.Float(c) * t**(len(coeff)-i-1) for i, c in enumerate(coeff))

def find_real_roots(expr, symbol, lo, hi):
    try:
        roots = sp.solve(sp.diff(expr, symbol), symbol)
        vals = []
        for root in roots:
            if root.is_real is True:
                val = float(root)
                if lo < val < hi and np.isfinite(val):
                    vals.append(val)
        return sorted(set(round(v, 8) for v in vals))
    except Exception:
        return []

def make_plot(x_obs, y_obs, f, domain, hist_end, x_point=None, tangent=None, secant=None,
              title="Population model", x_label="Year", y_label="Population (people)"):
    fig, ax = plt.subplots(figsize=(10, 5.2))
    xx = np.linspace(domain[0], domain[1], 700)
    yy = f(xx)
    yy = np.where(np.isfinite(yy), yy, np.nan)
    inside = xx <= hist_end
    if np.any(inside):
        ax.plot(xx[inside], yy[inside], linewidth=2.5, label="Model (historical domain)")
    if np.any(~inside):
        ax.plot(xx[~inside], yy[~inside], linewidth=2.5, linestyle="--", label="Extrapolated model")
    ax.scatter(x_obs, y_obs, s=58, zorder=4, label="Presentation data")
    ax.axvline(hist_end, color="gray", linestyle=":", label="End of observed range")
    if x_point is not None:
        yp = float(f(np.array([x_point]))[0])
        if np.isfinite(yp):
            ax.scatter([x_point], [yp], marker="D", s=85, label="Selected point", zorder=6)
    if tangent is not None:
        xp, yp, slope = tangent
        line_x = np.linspace(max(domain[0], xp-(domain[1]-domain[0])*.13), min(domain[1], xp+(domain[1]-domain[0])*.13), 60)
        ax.plot(line_x, yp+slope*(line_x-xp), linestyle="-.", label="Tangent line")
    if secant is not None:
        a,b,ya,yb = secant
        ax.plot([a,b],[ya,yb], linestyle=":", linewidth=2, label="Secant line")
    ax.set_title(title)
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.grid(alpha=.25)
    ax.legend()
    fig.tight_layout()
    return fig

def export_excel(summary, data, results):
    out = io.BytesIO()
    with pd.ExcelWriter(out, engine="xlsxwriter") as writer:
        pd.DataFrame({"Item": list(summary.keys()), "Value": list(summary.values())}).to_excel(writer, sheet_name="Summary", index=False)
        data.to_excel(writer, sheet_name="Working data", index=False)
        results.to_excel(writer, sheet_name="Calculated years", index=False)
    out.seek(0)
    return out.getvalue()

def export_pdf(summary, data, results, fig):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
    out = io.BytesIO()
    doc = SimpleDocTemplate(out, pagesize=letter, rightMargin=34, leftMargin=34, topMargin=30, bottomMargin=30)
    styles = getSampleStyleSheet()
    story = [Paragraph("Afro-Dominican Population Explorer", styles["Title"]),
             Paragraph("Classroom analysis using the estimates transcribed from the student's presentation.", styles["Normal"]),
             Spacer(1, 12)]
    rows = [["Item", "Value"]] + [[str(k), str(v)] for k,v in summary.items()]
    tab = Table(rows, colWidths=[150, 360], repeatRows=1)
    tab.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#102d82")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.grey),("FONTSIZE",(0,0),(-1,-1),8),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story += [tab, Spacer(1, 12)]
    img = io.BytesIO()
    fig.savefig(img, format="png", dpi=140, bbox_inches="tight")
    img.seek(0)
    story.append(RLImage(img, width=500, height=260))
    story += [Spacer(1, 10), Paragraph("Data preview", styles["Heading2"])]
    drows = [list(data.columns)] + data.head(15).astype(str).values.tolist()
    dt = Table(drows, repeatRows=1)
    dt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#f2c14e")),("GRID",(0,0),(-1,-1),.3,colors.grey),("FONTSIZE",(0,0),(-1,-1),7)]))
    story.append(dt)
    if not results.empty:
        story += [Spacer(1,10), Paragraph("Calculated years", styles["Heading2"])]
        rrows = [list(results.columns)] + results.astype(str).values.tolist()
        rt = Table(rrows, repeatRows=1)
        rt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#f2c14e")),("GRID",(0,0),(-1,-1),.3,colors.grey),("FONTSIZE",(0,0),(-1,-1),7)]))
        story.append(rt)
    doc.build(story)
    out.seek(0)
    return out.getvalue()

# ------------------------------- UI -------------------------------
st.markdown("""
<style>
.stApp {background: linear-gradient(135deg,#f8f4e9 0%,#fffaf0 55%,#f2f5ff 100%);}
.hero {background:#08266f;color:white;padding:1.25rem 1.5rem;border-radius:16px;border-bottom:7px solid #f4bd25;}
.hero h1 {color:white;margin:0;font-size:2.15rem;}
.hero p {color:#fff4d6;margin:.35rem 0 0 0;}
div[data-testid="stMetric"] {background:white;padding:12px;border-radius:12px;border:1px solid #e8e3d8;}
</style>
<div class="hero"><h1>🌺 Afro-Dominican Population Explorer</h1>
<p>Explore the estimates, investigate change, and experiment with mathematical models.</p></div>
""", unsafe_allow_html=True)
st.caption("The historical values below come from the population table in your uploaded presentation (page 2). They are estimates, not independently verified census counts.")
st.warning("Data note: the slide cites DBpedia and does not provide a detailed methodology for how the Afro-Dominican population estimates were produced. Treat the figures as a classroom dataset, not an official demographic series.")

with st.sidebar:
    st.header("Explore the model")
    mode = st.selectbox("Math pathway", MODES, index=2)
    degree = st.slider("Polynomial degree", 1, 8, 2, help="Degree 1 is linear; higher degrees can bend more and may behave unpredictably outside the observed years.")
    sample_step = st.slider("Model marker interval (years)", 1, 10, 5)
    horizon = st.slider("Forward display horizon (years)", 0, 50, 10)
    context = st.selectbox("Context", list(CONTEXTS.keys()), index=0)
    printer = st.toggle("Printer-friendly view", value=False)
    st.divider()
    st.subheader("Context settings")
    default_ctx = CONTEXTS[context]
    custom_description = st.text_area("Context description", value=default_ctx["description"])
    x_label = st.text_input("Independent variable", value=default_ctx["x"])
    x_unit = st.text_input("Independent-variable units", value=default_ctx["xunit"])
    y_label = st.text_input("Dependent variable", value=default_ctx["y"])
    y_unit = st.text_input("Dependent-variable units", value=default_ctx["yunit"])

# Session-state editable data
if "working_data" not in st.session_state:
    st.session_state.working_data = SOURCE_DF.copy()
st.subheader("1. Historical data")
left, right = st.columns([1.2, 1])
with left:
    st.write("Edit the table to test how changing a value affects the model. Use **Reset to source** to restore the slide values.")
    edited = st.data_editor(st.session_state.working_data, num_rows="dynamic", use_container_width=True, key="data_editor")
    c1,c2 = st.columns(2)
    if c1.button("Apply table edits", type="primary", use_container_width=True):
        st.session_state.working_data = edited.copy()
        st.rerun()
    if c2.button("Reset to source", use_container_width=True):
        st.session_state.working_data = SOURCE_DF.copy()
        st.rerun()
    raw = st.session_state.working_data.copy()
with right:
    st.markdown("**What the original presentation reports**")
    st.metric("1950 estimate", "500,000")
    st.metric("2024 estimate", "2,600,000")
    st.metric("Total increase", "420%")
    st.info("The presentation's table lists ten years: 1950, 1960, 1970, 1980, 1990, 2000, 2010, 2015, 2020 and 2024.")

# Validate
try:
    raw["Year"] = pd.to_numeric(raw["Year"], errors="raise")
    raw["Estimated population"] = pd.to_numeric(raw["Estimated population"], errors="raise")
    if raw.empty or raw.isna().any().any():
        raise ValueError("Missing year or population values are not allowed.")
    if not np.all(raw["Year"].to_numpy() == raw["Year"].astype(int).to_numpy()):
        raise ValueError("Years must be whole numbers.")
    raw["Year"] = raw["Year"].astype(int)
    if raw["Year"].duplicated().any():
        raise ValueError("Each year must be unique. Remove duplicate years.")
    if (raw["Estimated population"] < 0).any():
        raise ValueError("Population values cannot be negative.")
    if len(raw) < degree + 1:
        raise ValueError(f"Degree {degree} needs at least {degree+1} distinct observations.")
    raw = raw.sort_values("Year").reset_index(drop=True)
except Exception as e:
    st.error(f"Data validation: {e}")
    st.stop()

is_edited = not raw.equals(SOURCE_DF)
if is_edited:
    st.info("User-modified scenario: calculations and downloads use the edited table.")

# Model source selection
st.subheader("2. Choose or build a function")
function_choice = st.radio("Function source", FUNCTIONS, horizontal=True)
x = sp.Symbol("x", real=True)
base, coeff, fitted, residuals, r2, mae = polyfit_model(raw, min(degree, len(raw)-1))
data_expr = poly_expr(coeff, base, x)
suggestion = CONTEXTS[context]["suggestion"]
param_expr = None

if function_choice == "Data best-fit polynomial":
    expr = data_expr
    function_label = f"Degree {len(coeff)-1} polynomial fitted to the working data"
elif function_choice == "Suggested function":
    if suggestion == "exponential":
        a = st.number_input("Suggested exponential scale", value=1.0)
        k = st.number_input("Suggested exponential rate", value=0.02, format="%.4f")
        expr = sp.Float(a) * sp.exp(sp.Float(k)*(x-sp.Float(base)))
    elif suggestion == "logarithmic":
        a = st.number_input("Log coefficient", value=1.0)
        b = st.number_input("Log offset", value=1.0, min_value=0.001)
        expr = sp.Float(a)*sp.log(x-sp.Float(raw["Year"].min())+sp.Float(b))
    elif suggestion == "trigonometric":
        a = st.number_input("Amplitude", value=1.0)
        k = st.number_input("Angular frequency", value=0.2)
        expr = sp.Float(a)*sp.sin(sp.Float(k)*x)
    else:
        a = st.number_input("Quadratic coefficient a", value=1.0)
        b = st.number_input("Linear coefficient b", value=0.0)
        c = st.number_input("Constant c", value=0.0)
        expr = sp.Float(a)*x**2+sp.Float(b)*x+sp.Float(c)
    function_label = f"Suggested {suggestion} function (parameterized example)"
elif function_choice == "Build with parameters":
    kind = st.selectbox("Function family", ["Polynomial (quadratic)", "Exponential", "Logarithmic", "Trigonometric", "Rational"])
    if kind == "Polynomial (quadratic)":
        a=st.number_input("a",value=1.0); b=st.number_input("b",value=0.0); c=st.number_input("c",value=0.0)
        expr=sp.Float(a)*x**2+sp.Float(b)*x+sp.Float(c)
    elif kind == "Exponential":
        a=st.number_input("Scale a",value=1.0); k=st.number_input("Rate k",value=.01,format="%.4f")
        expr=sp.Float(a)*sp.exp(sp.Float(k)*x)
    elif kind == "Logarithmic":
        a=st.number_input("Coefficient a",value=1.0); b=st.number_input("Shift b",value=1.0,min_value=.001)
        expr=sp.Float(a)*sp.log(x+sp.Float(b))
    elif kind == "Trigonometric":
        a=st.number_input("Amplitude a",value=1.0); k=st.number_input("Frequency k",value=1.0)
        expr=sp.Float(a)*sp.sin(sp.Float(k)*x)
    else:
        a=st.number_input("Numerator scale a",value=1.0); b=st.number_input("Denominator shift b",value=1.0,min_value=.001); c=st.number_input("Vertical shift c",value=0.0)
        expr=sp.Float(a)/(x+sp.Float(b))+sp.Float(c)
    function_label = f"User-parameterized {kind.lower()} function"
else:
    default_text = "0.0001*(x-1950)**2 + 20000*(x-1950) + 500000" if context == "Population / biology" else "2*x + 1"
    user_text = st.text_input("Enter f(x) using x, + - * /, powers, sin, cos, tan, exp, log, sqrt", value=default_text)
    try:
        expr = safe_expression(user_text, x)
        function_label = "Custom function entered by user"
    except ValueError as e:
        st.error(str(e))
        st.stop()

st.markdown(f"**Active function:** `{sp.sstr(expr)}`")
st.caption(f"Context: {custom_description}")

try:
    f = numeric_function(expr, x)
    # Test representative points to catch unusable expressions.
    test_vals = f(np.array([float(raw.Year.min()), float(raw.Year.max())]))
    if not np.all(np.isfinite(test_vals)):
        st.warning("The selected function is undefined at one or more ends of the observed interval. The graph will leave gaps where it is undefined.")
except Exception as e:
    st.error(f"Function evaluation error: {e}")
    st.stop()

# Analysis interval and sliders
min_x, max_x = float(raw.Year.min()), float(raw.Year.max())
domain_lo = st.number_input(f"Analysis interval start ({x_unit})", value=float(min_x))
domain_hi = st.number_input(f"Analysis interval end ({x_unit})", value=float(max_x))
if domain_hi <= domain_lo:
    st.error("The analysis interval end must be greater than the start.")
    st.stop()
st.subheader("3. Graph and quantitative analysis")
default_point = float(np.clip((domain_lo+domain_hi)/2, domain_lo, domain_hi))
point = st.slider(f"Select input value ({x_label})", min_value=float(domain_lo), max_value=float(domain_hi), value=default_point, step=max((domain_hi-domain_lo)/200, .01))
colA,colB,colC = st.columns(3)
with colA:
    aroc_start = st.number_input("Average-rate interval start", value=float(domain_lo))
with colB:
    aroc_end = st.number_input("Average-rate interval end", value=float(domain_hi))
with colC:
    sim_speed = st.select_slider("Simulation step size", options=["Slow","Medium","Fast"], value="Medium")
if aroc_end <= aroc_start:
    st.error("Average-rate interval end must be greater than its start.")
    st.stop()

d1 = sp.diff(expr, x)
d2 = sp.diff(d1, x)
f1 = numeric_function(d1, x)
f2 = numeric_function(d2, x)
try:
    y_point = float(f(np.array([point]))[0])
    slope = float(f1(np.array([point]))[0])
    curvature = float(f2(np.array([point]))[0])
    ya = float(f(np.array([aroc_start]))[0]); yb = float(f(np.array([aroc_end]))[0])
    avg_rate = (yb-ya)/(aroc_end-aroc_start) if np.isfinite(ya+yb) else float("nan")
except Exception:
    y_point=slope=curvature=avg_rate=float("nan")
    ya=yb=float("nan")

fig = make_plot(raw.Year.to_numpy(), raw["Estimated population"].to_numpy(), f,
                (min(domain_lo, min_x), max(domain_hi, max_x+horizon)), max_x,
                x_point=point,
                tangent=(point,y_point,slope) if np.isfinite(y_point+slope) else None,
                secant=(aroc_start,aroc_end,ya,yb) if np.isfinite(ya+yb) else None,
                title=f"{context}: {y_label} vs {x_label}", x_label=f"{x_label} ({x_unit})", y_label=f"{y_label} ({y_unit})")
st.pyplot(fig, use_container_width=True)

m1,m2,m3,m4 = st.columns(4)
m1.metric("Function value", fmt_num(y_point), y_unit)
m2.metric("Instantaneous rate f′(x)", fmt_num(slope), f"{y_unit} per {x_unit}")
m3.metric("Second derivative f″(x)", fmt_num(curvature), f"{y_unit} per {x_unit}²")
m4.metric("Average rate of change", fmt_num(avg_rate), f"{y_unit} per {x_unit}")
st.write(f"**Secant calculation:** ({fmt_num(yb)} − {fmt_num(ya)}) ÷ ({fmt_num(aroc_end)} − {fmt_num(aroc_start)}) = **{fmt_num(avg_rate)} {y_unit} per {x_unit}**.")
st.write(f"At x = **{fmt_num(point)}**, the tangent slope is **{fmt_num(slope)} {y_unit} per {x_unit}**.")

# Math pathway depth
st.subheader("4. Function analysis")
st.markdown(f"- **Function:** \(f(x) = {sp.latex(expr)}\)")
if mode in ["Precalculus", "Calculus"]:
    st.markdown(f"- **First derivative:** \(f'(x) = {sp.latex(d1)}\)")
    st.markdown(f"- **Second derivative:** \(f''(x) = {sp.latex(d2)}\)")
if mode == "Calculus":
    st.markdown("**Derivative interpretation:** The first derivative is the instantaneous rate at which the dependent variable changes for each unit of the independent variable. The second derivative describes how that rate changes.")
    st.markdown(f"- At x = {fmt_num(point)}, f′(x) = {fmt_num(slope)} {y_unit}/{x_unit}; f″(x) = {fmt_num(curvature)} {y_unit}/{x_unit}².")
    critical = find_real_roots(expr, x, domain_lo, domain_hi)
    inflections = []
    try:
        for rr in sp.solve(d2, x):
            if rr.is_real is True and domain_lo < float(rr) < domain_hi:
                rv=float(rr); eps=max((domain_hi-domain_lo)*1e-4,1e-5)
                l=float(f2(np.array([rv-eps]))[0]); r=float(f2(np.array([rv+eps]))[0])
                if np.isfinite(l+r) and l*r < 0: inflections.append(rv)
    except Exception:
        pass
    if critical:
        rows=[]
        for cpt in critical:
            eps=max((domain_hi-domain_lo)*1e-4,1e-5)
            left_s=float(f1(np.array([cpt-eps]))[0]); right_s=float(f1(np.array([cpt+eps]))[0])
            typ="local minimum" if left_s<0<right_s else "local maximum" if left_s>0>right_s else "stationary point (not classified as an extremum)"
            rows.append({"x":cpt,"f(x)":float(f(np.array([cpt]))[0]),"classification":typ})
        st.write("**Critical points (symbolic solutions in the selected interval):**")
        st.dataframe(pd.DataFrame(rows), use_container_width=True)
    else:
        st.write("No critical points were found symbolically in the selected interval.")
    st.write("**Inflection points:** " + (", ".join(fmt_num(v) for v in inflections) if inflections else "No concavity-changing inflection point was confirmed in this interval."))
    if critical or inflections:
        st.caption("Critical points are classified by checking the sign of f′ on either side. Inflection points are included only when the sign of f″ changes.")
    st.write("**Domain note:** Rational and logarithmic functions can be undefined at restricted inputs. The plotted curve omits non-finite values instead of joining across gaps.")
else:
    st.markdown(f"- **Domain examined:** [{fmt_num(domain_lo)}, {fmt_num(domain_hi)}]")
    st.markdown(f"- **Range on sampled graph:** {fmt_num(np.nanmin(f(np.linspace(domain_lo,domain_hi,500))))} to {fmt_num(np.nanmax(f(np.linspace(domain_lo,domain_hi,500))))} {y_unit}")
    st.markdown("**Interpretation:** Use the graph and average rate to describe where the model rises, falls, or changes more quickly.")

# Simulation controls: point is synchronized with the graph and values.
st.subheader("5. Interactive visual simulation")
st.caption("Move the input slider to move the highlighted point and update the function value, tangent slope, and second derivative. The buttons step the selected input; use the slider for continuous manual control.")
step = {"Slow": 0.005, "Medium": 0.02, "Fast": 0.05}[sim_speed] * (domain_hi-domain_lo)
sim1,sim2,sim3 = st.columns(3)
if sim1.button("▶ Advance"):
    st.session_state["sim_point"] = min(domain_hi, float(st.session_state.get("sim_point", point))+step)
    st.rerun()
if sim2.button("⏸ Pause"):
    st.session_state["sim_paused"] = True
    st.success("Simulation paused. Move the slider or press Advance to continue.")
if sim3.button("↺ Reset point"):
    st.session_state["sim_point"] = default_point
    st.rerun()

# Historical data regression statistics (distinct from whichever function is active)
st.subheader("6. Data statistics and model quality")
base, coeff, fitted, resid, r2, mae = polyfit_model(raw, min(degree, len(raw)-1))
avg_full = (raw["Estimated population"].iloc[-1]-raw["Estimated population"].iloc[0])/(raw["Year"].iloc[-1]-raw["Year"].iloc[0])
growth_pct = (raw["Estimated population"].iloc[-1]/raw["Estimated population"].iloc[0]-1)*100
stat1,stat2,stat3,stat4 = st.columns(4)
stat1.metric("Mean population", fmt_num(raw["Estimated population"].mean()), "people")
stat2.metric("Median population", fmt_num(raw["Estimated population"].median()), "people")
stat3.metric("Total change", f"{growth_pct:.1f}%", "1950 to latest year")
stat4.metric("Average rate", fmt_num(avg_full), "people per year")
st.write(f"**Regression fit (degree {min(degree,len(raw)-1)}):** base year = {base:.2f}; R² = {r2:.5f}; MAE = {mae:,.0f} people.")
st.caption("R² and MAE describe the polynomial's fit to these same observations (in-sample); they do not prove forecast accuracy.")
residual_df = pd.DataFrame({"Year":raw.Year,"Observed":raw["Estimated population"],"Fitted":fitted,"Residual (observed − fitted)":resid})
with st.expander("View regression residuals"):
    st.dataframe(residual_df, use_container_width=True)

# Degree comparison and chronological holdout
dcomp=[]
for deg in range(1, min(6,len(raw)-1)+1):
    _, cc, pp, rr, rr2, mm = polyfit_model(raw,deg)
    dcomp.append({"Degree":deg,"R² (in-sample)":rr2,"MAE (people)":mm})
st.write("**Compare polynomial degrees**")
st.dataframe(pd.DataFrame(dcomp), use_container_width=True)
if len(raw) >= 7:
    train_n = max(4, len(raw)-3)
    train = raw.iloc[:train_n]
    test = raw.iloc[train_n:]
    hd = min(degree, len(train)-1)
    hb,hc,*_ = polyfit_model(train,hd)
    hold_pred=np.polyval(hc,test.Year.to_numpy(dtype=float)-hb)
    hold_mae=float(np.mean(np.abs(test["Estimated population"].to_numpy()-hold_pred)))
    st.write(f"**Chronological holdout:** fit first {train_n} observations, evaluate the latest {len(test)} observations; holdout MAE = **{hold_mae:,.0f} people** (degree {hd}).")
else:
    st.write("Not enough observations for a three-point chronological holdout.")

# Single and batch predictions use the active expression
st.subheader("7. Single-year and batch estimates")
single_year = st.number_input("Calculate function value at input", min_value=1950, max_value=2100, value=2030, step=1)
if st.button("Calculate single value", type="primary"):
    val=float(f(np.array([single_year]))[0])
    classification = "within selected analysis interval" if domain_lo <= single_year <= domain_hi else "outside selected analysis interval (extrapolation)"
    observed = raw.loc[raw.Year==single_year,"Estimated population"]
    st.session_state["single_result"] = {"Year":int(single_year),"Estimate":val,"Units":y_unit,"Classification":classification,"Observed slide value":float(observed.iloc[0]) if len(observed) else None}
if "single_result" in st.session_state:
    st.json(st.session_state["single_result"])

batch_mode = st.radio("Batch input", ["Year range","Custom years"], horizontal=True)
valid_years=[]
if batch_mode=="Year range":
    b1,b2,b3=st.columns(3)
    start=b1.number_input("Start year",1950,2100,2025)
    end=b2.number_input("End year",1950,2100,2050)
    stride=b3.number_input("Step",1,10,5)
    if end<=start:
        st.error("End year must be greater than start year.")
    else:
        valid_years=list(range(int(start),int(end)+1,int(stride)))
else:
    custom=st.text_input("Enter years separated by commas",value="2025, 2030, 2040, 2050")
    valid=[]; invalid=[]
    for token in custom.split(","):
        token=token.strip()
        if not token: continue
        if re.fullmatch(r"\d{4}",token) and 1950<=int(token)<=2100:
            valid.append(int(token))
        else: invalid.append(token)
    valid_years=sorted(set(valid))
    if invalid: st.warning("Ignored invalid or out-of-range entries: "+", ".join(invalid))
    if len(valid)!=len(valid_years): st.info("Duplicate years were removed.")
st.write("**Years ready to calculate:**", valid_years if valid_years else "No valid years")
if st.button("Calculate batch", disabled=not valid_years):
    out_rows=[]
    for yr in valid_years:
        value=float(f(np.array([yr]))[0])
        label="within selected analysis interval" if domain_lo<=yr<=domain_hi else "outside selected analysis interval (extrapolation)"
        out_rows.append({"Year":yr,"Estimate":value,"Units":y_unit,"Calculation type":label})
    st.session_state["batch_results"]=pd.DataFrame(out_rows)
if "batch_results" in st.session_state:
    st.dataframe(st.session_state["batch_results"],use_container_width=True)

# Contextual interpretation / cautions
st.subheader("8. Findings and limitations")
st.markdown(f"""
- The presentation's estimated population rises from **500,000 in 1950** to **2,600,000 in 2024**, a **420% increase** based on the listed endpoints.
- The average rate across the full period is approximately **{avg_full:,.0f} people per year**. This is an average across a 74-year interval, not a claim that growth was constant each year.
- The data table has only ten observations, with unequal time gaps after 2010. A fitted curve summarizes the listed points but cannot reveal the reasons behind demographic change.
- The slide source does not explain the population-identification method or uncertainty. The estimates should not be treated as an official count of everyone of African descent in the Dominican Republic.
""")
st.markdown("**Follow-up question:** How might the estimate change if a consistent, clearly defined census measure of racial or ethnic self-identification were available across decades?")
st.caption("Forecast caution: polynomial models can become unrealistic far beyond the observed years. This app does not provide statistically validated prediction intervals. A small residual or high R² is not a guarantee of future accuracy.")

# Exports
st.subheader("9. Download your analysis")
active_data = raw.copy()
active_data["Scenario"] = "User-modified" if is_edited else "Original slide dataset"
results_df = st.session_state.get("batch_results",pd.DataFrame())
summary = {
    "Generated":datetime.now().isoformat(timespec="seconds"),
    "Data source":"User presentation, page 2; slide cites DBpedia (methodology not supplied)",
    "Scenario":"User-modified" if is_edited else "Original slide dataset",
    "Context":context,"Context description":custom_description,
    "Function":str(expr),"Math pathway":mode,
    "Regression degree":min(degree,len(raw)-1),"Regression base year":base,
    "Regression R-squared (in-sample)":r2,"Regression MAE (people)":mae,
    "Observed coverage":f"{raw.Year.min()}-{raw.Year.max()}","Observation count":len(raw),
    "Active function first derivative":str(d1),"Active function second derivative":str(d2),
}
csv_bytes=active_data.to_csv(index=False).encode("utf-8")
xlsx_bytes=export_excel(summary,active_data,results_df)
pdf_bytes=export_pdf(summary,active_data,results_df,fig)
d1c,d2c,d3c=st.columns(3)
d1c.download_button("⬇ Download CSV",csv_bytes,"afro_dominican_population_data.csv","text/csv",use_container_width=True)
d2c.download_button("⬇ Download Excel",xlsx_bytes,"afro_dominican_population_analysis.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",use_container_width=True)
d3c.download_button("⬇ Download PDF report",pdf_bytes,"afro_dominican_population_report.pdf","application/pdf",use_container_width=True)

with st.expander("How to run / deploy"):
    st.code("pip install -r requirements.txt\nstreamlit run app.py --server.port $PORT --server.address 0.0.0.0",language="bash")
    st.write("Upload app.py and requirements.txt to the root of a GitHub repository, then deploy that repository as a Streamlit Community Cloud app. Set the main file path to app.py.")
